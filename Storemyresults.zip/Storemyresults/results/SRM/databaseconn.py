import mysql.connector
import webbrowser

import cgi,os
mydb=mysql.connector.connect(host='localhost',user='root',passwd='123456',database='storeresult',autocommit=True)
cursor=mydb.cursor()
# form=cgi.FieldStorage()
# username=str(form.getvalue("username"))
username="1RR19IS001"
match username:
    case "1RR19IS001":
        cursor.execute("select * from sem1rec1")
        x=cursor.fetchall()
        # print(x)
        for row in x:
            print("SUBJECTCODE:",row[0])
            print("SUBJECTNAME:",row[1])
            print("INTERNALMARKS:",row[2])
            print("EXTERNALMARKS:",row[3])
            print("TOTAL:",row[4])
            print("RESULT:",row[5])
    case "1RR19IS002":
        cursor.execute("select * from sem1rec2")
        x=cursor.fetchall()
        print(x)
    case "1RR19IS003":
        cursor.execute("select * from sem1rec3")
        x=cursor.fetchall()
        print(x)
    case "1RR19IS004":
        cursor.execute("select * from sem1rec4")
        x=cursor.fetchall()
        print(x)
f=open("result.html","w")   
message='''
<html>
<body> <h1>hi1<h1>
</body></html> '''
f.write(message)
f.close()
webbrowser.open_new_tab("result.html")
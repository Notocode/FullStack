import webbrowser
f=open("res.html","w")
message='''
<html>
<head></head>
<form action="contact" method="post">
            <input type="text" class="form-control"  name="name">
            <label>Email*</label>
            <input type="text"class="form-control" name="text"required>
            <label>Message</label>
            <textarea  name="comment"class="form-control" name="text">
            </textarea>           
            <input type="submit"  class="btn" value="submit" onclick="return confirm('your message submitted')"> 















</body>
</html>
'''
